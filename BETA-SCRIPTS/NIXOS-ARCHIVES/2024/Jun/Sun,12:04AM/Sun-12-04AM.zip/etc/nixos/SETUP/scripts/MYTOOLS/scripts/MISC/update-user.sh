#!/bin/sh
# update nixos packages for user

nix-channel --update
