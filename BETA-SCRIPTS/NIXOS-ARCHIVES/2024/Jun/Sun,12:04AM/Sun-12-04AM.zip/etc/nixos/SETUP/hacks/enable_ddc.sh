sudo chmod a+rw /dev/i2c-*
