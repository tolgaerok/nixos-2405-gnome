#!/bin/sh

echo -e " W T F "
