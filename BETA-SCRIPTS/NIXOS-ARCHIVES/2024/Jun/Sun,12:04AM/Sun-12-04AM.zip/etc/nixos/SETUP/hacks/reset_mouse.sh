sudo rmmod i2c_hid_acpi
sudo modprobe i2c_hid_acpi
