#!/run/current-system/sw/bin/sh

# Run your custom info script here
/etc/nixos/core/system/systemd/custom-info-script.sh
